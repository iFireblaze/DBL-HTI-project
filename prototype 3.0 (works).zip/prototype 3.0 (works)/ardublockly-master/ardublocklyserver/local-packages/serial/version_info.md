The version of pyserial included here is v3.2.1
commit ffb44d6d7394e2b73bfb1bb91dd69c377c0f8aa0

https://github.com/pyserial/pyserial/releases/tag/v3.2.1

This package has no dependencies.

No modifications have been made.
